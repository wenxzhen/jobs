// https://developer.mozilla.org/en-US/docs/Web/API/ClipboardEvent/ClipboardEvent
// https://developer.mozilla.org/en-US/docs/Web/API/Window/getSelection
// Support  >=ie9
var G = function (a, b, c) {
    // 拼接字符串
    function d_text(b, c) {
        return ['',
            '作者：' + c,
            '链接：' + b,
            '来源：OrcHome',
            '著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。',
            '',''
        ]
    }

    // 拼接字符串
    function d_html(b, c) {
        return ['',
            '',
            '作者：' + c,
            '链接：' + b,
            '来源：OrcHome',
            '著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。',
            ''
        ]
    }

    // 拼接成html
    function assemblyHtml(b, c, m) {
        return "\x3cdiv\x3e" + m + d_html(b, c).join("\x3cbr /\x3e") + "\x3cdiv\x3e"
    }

    function RegExp(h) {
        // 中文
        var reg = /[\u4e00-\u9fa5]/;

        if (reg.test(h)) {
            return true;
        }
        return false;
    }

    // 处理 copy
    function g(a) {
        if (!window.getSelection) {
            return;
        }

        var range = window.getSelection().getRangeAt(0);
        var container = window.document.createElement('div');
        container.appendChild(range.cloneContents());
        var html_h = container.innerHTML;
        if (!RegExp(html_h)) {
            return;
        }

        if ('object' === typeof a.originalEvent.clipboardData) {
            var m = window.getSelection().toString();
            a.originalEvent.clipboardData.setData('text/html', assemblyHtml(b, c, html_h));
            a.originalEvent.clipboardData.setData('text/plain', d_text(b, c).join('\n') + m);
            a.preventDefault();

            return;
        }

        var n = $(f(b, c, m)).css({
            position: 'fixed',
            left: '-9999px'
        }).appendTo('body');
        window.getSelection().selectAllChildren(n[0]);

    }

    function hander(a) {
        g(a);
        //alert('复制好了, 请粘贴内容!');
    }

    // 绑定copy事件
    a.on('copy', hander);
}

var a = $('.p1');
G(a, location.href, a.data('name'))