$(function () {
    //设置文本框验证功能
    $("form").not(".noValidate").validate();
    initDate();
    cachePageInfo();
    /**
     * 点击行选择radio标签
     */
    $(".contextTR").click(function () {
        $("input[name='selectCheckBox']").prop("checked", false);
        var $obj = $("#" + $(this).attr("data-radio"));
        $obj.prop("checked", true);
        $obj.change();
        $("#main-table>tbody>tr").css("background-color", "");
        $(this).css("background-color", "#62a8d1");
    });


    /**********设置全选和不全选*********/
    var $selectAll = $(".selectAll");
    $selectAll.unbind("click");
    $selectAll.bind("click", function () {
        var $obj = $(".selectAll");
        var selectChecked = $obj.prop("checked");
        $("input[name=" + $obj.attr("name") + "]").each(function (i) {
            if (!$(this).parent().is(":hidden")) {
                $(this).prop("checked", selectChecked);
            }
        });
    });

    jQuery("#stretchButton").click(function (e) {
        e.preventDefault();
        if ($(this).attr("data-item") == "1") {
            $(this).attr("data-item", "2");
            $(this).attr("id", "clickStretchButton");
            var $portletBody = $("#portlet-body");
            var $Object = $("#main-context");
            var portletBodyHeight = $portletBody.outerHeight();
            $portletBody.slideUp(700);
            if ($Object.length > 0) {
                //设置内容页高度
                $Object.css("height", $(document.body).height() + portletBodyHeight - $Object.offset().top - $("#pagingbar").outerHeight());
                $portletBody.attr("data-height", portletBodyHeight);
            }
        } else {
            $(this).attr("data-item", "1");
            var $portletBody = $("#portlet-body");
            $portletBody.slideDown(700);
            $(this).attr("id", "stretchButton");
            var $Object = $("#main-context");
            if ($Object.length > 0) {
                //设置内容页高度
                $Object.css("height", $(document.body).height() - $portletBody.attr("data-height") - $Object.offset().top - $("#pagingbar").outerHeight());
            }
        }
    });

    //设置表头不换行
    $(".table .breadcrumb th").addClass("navbar-inner");
    $(".table .breadcrumb th").css({
        "border": "0px solid #dddddd", "height": "28px",
        "border-left": "1px solid #dddddd", "border-radius": "1px"
    });


    /************重置按钮事件**************/
    $(".reset").unbind("click");
    $(".reset").bind('click', function () {
        resetPageInfo();
        $(".tipsy").remove();
        $(".formError").remove();
    });

    $(".monthStyle").unbind("keyup");
    $(".monthStyle").bind("keyup", function () {
        var v = $.trim($(this).val());
        var reg = /^\d{1,3}$/;
        if (!v.match(reg)) {
            $(this).val("");
        }
    });

    $("input").attr("autocomplete", "off");


    /******双击查看详情 *******/
    $(".dbClassStyle").parent().parent().addClass("handStyle");
    //noTitle 在操作的td上面加上这个class ，那列就不会有“双击查看详情”的提示
    $(".dbClassStyle").parent().siblings().not(".noTitle").attr("title", "双击查看详情");
    $(".dbClassStyle").parent().parent().unbind("dblclick");
    $(".dbClassStyle").parent().parent().dblclick(function () {
        wopen($(this).find(".dbClassStyle").val());
    });


    $(".noTitle").find("a").each(function () {
        var obj = $(this).prev();
        if (obj == undefined || !obj.hasClass("noTitleForA")) {
            if ($.trim($(this).html()) != '') {
                $(this).before("[");
                $(this).after("]");
            }
        }
    });

    $(".noTitle").find("span").each(function () {
        var obj = $(this).prev();
        if (obj == undefined || !obj.hasClass("noTitleForA")) {
            if ($.trim($(this).html()) != '') {
                $(this).before("[");
                $(this).after("]");
            }
        }
    });
    $(".noTitle").each(function () {
        var width = $(this).attr("width");
        if (width == undefined || width == '') {
            $(this).attr("width", "15%");
        }
    });

    //设置select宽度
    $("select").each(function () {
        //不需要设置宽度的可以加上这个class
        if (!$(this).hasClass("noSelectStyle")) {
            $(this).css("width", "150px");
        }
    });


    //鼠标手型样式
    $(".handStyle").css("cursor", "pointer");
    $(".red").css("color", "red");
    //表头不换行样式
    //$(".tr1").attr("nowrap","nowrap");
    //只读样式
    $(".readonly").after("<span style=\"color:red;\">不能修改</span>");
    $(".readonly").attr("title", "不能修改");
    //注释的样式
    $(".annotationStyle").css({"color": "green", "font-style": "italic", "font-size": "12px"});
    //$(".annotationStyle").css("font-style","italic");
    //必填项样式
    $(".required").each(function () {
        if (!$(this).next().hasClass("infoClass")) {
            $(this).after("<span class=\"infoClass\" style=\"color:red;\"> * </span>");
        }
    });

    //必填项样式
    $(".isRequired").each(function () {
        if (!$(this).next().hasClass("infoClass")) {
            $(this).after("<span class=\"infoClass\" style=\"color:#51a351;\"> * </span>");
        }
    });
    //根据商户分组
    if ($(".rowspanStyle").hasClass("hasRowspanStyle") == false) {
        $(".rowspanStyle").each(function () {
            var obj = $(".rowspanStyle[value=" + $(this).val() + "]");
            if ($(this).hasClass("hasHide") == false) {
                obj.addClass("hasHide");
                $(this).parent().attr("rowspan", obj.length);
                $(this).parent().attr("width", "40px");
                var nextObj = $(this).parent().next();
                if (nextObj != undefined) {
                    nextObj.attr("rowspan", obj.length);
                    nextObj.attr("width", "10%");
                }
                $(this).parent().show();
            } else {
                $(this).parent().hide();
                $(this).parent().addClass("hasHide");
                $(this).parent().next().hide();
                $(this).parent().next().addClass("hasHide");
            }
        });
        $(".rowspanStyle").addClass("hasRowspanStyle");
    }
    //根据商户 操作分组
    if ($(".rowspanStyleOperate").hasClass("hasRowspanStyle") == false) {
        $(".rowspanStyleOperate").each(function () {
            var obj = $(".rowspanStyleOperate[value=" + $(this).val() + "]");
            if ($(this).hasClass("hasHide") == false) {
                obj.addClass("hasHide");
                $(this).parent().attr("rowspan", obj.length);
                $(this).parent().attr("width", "15%");
                var nextObj = $(this).parent().next();
                if (nextObj != undefined) {
                    nextObj.attr("rowspan", obj.length);
                    nextObj.attr("width", "10%");
                }
                $(this).parent().show();
            } else {
                $(this).parent().hide();
                $(this).parent().addClass("hasHide");
                $(this).parent().next().hide();
                $(this).parent().next().addClass("hasHide");
            }
        });
        $(".rowspanStyleOperate").addClass("hasRowspanStyle");
    }

    if ($(".rowspanStyleOne").hasClass("hasRowspanStyleOne") == false) {
        $(".rowspanStyleOne").each(function () {
            var obj = $(".rowspanStyleOne[value=" + $(this).val() + "]");
            if ($(this).hasClass("hasHide") == false) {
                obj.addClass("hasHide");
                $(this).parent().attr("rowspan", obj.length);
                $(this).parent().show();
            } else {
                $(this).parent().hide();
                $(this).parent().addClass("hasHide");
            }
        });
        $(".rowspanStyleOne").addClass("hasRowspanStyleOne");
    }
    document.onkeydown = function (e) {
        var isie = (document.all) ? true : false;
        var key;
        var ev;
        if (isie) {//IE浏览器
            key = window.event.keyCode;
            ev = window.event;
        } else {//火狐浏览器
            key = e.which;
            ev = e;
        }
        if (key == 9) {//IE浏览器
            if (isie) {
                ev.keyCode = 0;
                ev.returnValue = false;
            } else {//火狐浏览器
                ev.which = 0;
                ev.preventDefault();
            }
        }
    }


});


function initialData(clrDate) {
    //初始化时间
    $(".yestoday").val(sys_getDate(null, {dateDiff: -1}));  //前一天
    $("input.today").val(sys_getDate());  //当天
    $("div.today").html(sys_getDate());  //当天
    $(".currentMonth").val(sys_getDate("YYYYMM"));  //当月
    if (clrDate != "") {
        $(".beforeMonth").val(clrDate);
    } else {
        $(".beforeMonth").val(sys_getDate("YYYYMM", {monthDiff: -1}));//前一个月
    }
}

function sys_getDate(format, options) {

    var sys_cal_calendar = new Date();

    if (options) {
        if (options.dateDiff) sys_cal_calendar.setDate(sys_cal_calendar.getDate() + options.dateDiff);
        if (options.monthDiff) sys_cal_calendar.setMonth(sys_cal_calendar.getMonth() + options.monthDiff);
        if (options.yearDiff) sys_cal_calendar.setYear(sys_cal_calendar.getYear() + options.yearDiff);
    }

    var sys_cal_year = sys_cal_calendar.getFullYear();  // 年
    var sys_cal_month = sys_cal_calendar.getMonth() + 1;  // 月
    var sys_cal_date = sys_cal_calendar.getDate();  // 日
    var sys_cal_day = sys_cal_calendar.getDay();  // 星期（几）
    var sys_cal_hour = sys_cal_calendar.getHours();  // 时
    var sys_cal_miniute = sys_cal_calendar.getMinutes();  // 分
    var sys_cal_second = sys_cal_calendar.getSeconds();  // 秒

    var date = '';
    this.formerDate = false;  // xuqq 2010-8-16

    if (!format) {
        date += sys_cal_year;
        date += '' + (sys_cal_month.toString().length == 1 ? ('0' + sys_cal_month) : sys_cal_month);
        date += '-' + (sys_cal_date.toString().length == 1 ? ('0' + sys_cal_date) : sys_cal_date);
    } else {
        if (format.indexOf('YYYY') >= 0) {
            date += sys_cal_year;
            this.formerDate = true;
        }
        if (format.indexOf('MM') >= 0) {
            date += ('') + (sys_cal_month.toString().length == 1 ? ('0' + sys_cal_month) : sys_cal_month);
            this.formerDate = true;
        }
        if (format.indexOf('DD') >= 0) {
            date += (this.formerDate ? '-' : '') + (sys_cal_date.toString().length == 1 ? ('0' + sys_cal_date) : sys_cal_date);
            this.formerDate = true;
        }
        if (format.indexOf('HH') >= 0) {
            date += (this.formerDate ? ' ' : '') + (sys_cal_hour.toString().length == 1 ? ('0' + sys_cal_hour) : sys_cal_hour);
            this.formerTime = true;
        }
        if (format.indexOf('MI') >= 0) {
            date += (this.formerTime ? ':' : (this.formerDate ? ' ' : '')) + (sys_cal_miniute.toString().length == 1 ? ('0' + sys_cal_miniute) : sys_cal_miniute);
            this.formerTime = true;
        }
        if (format.indexOf('SS') >= 0) {
            date += (this.formerTime ? ':' : (this.formerDate ? ' ' : '')) + (sys_cal_second.toString().length == 1 ? ('0' + sys_cal_second) : sys_cal_second);
            this.formerTime = true;
        }
    }
    return date;
}


function toUrl(url) {
    if (url.indexOf("?") == -1) {
        url = url + "?t=" + new Date().getTime();
    } else {
        url = url + "&t=" + new Date().getTime();
    }
    location.href = url;
}


function wopen(title, url, width, height, initMaximizable) {
    if (url.indexOf("?") == -1) {
        url = url + "?t=" + new Date().getTime();
    } else {
        url = url + "&t=" + new Date().getTime();
    }
    width = width ? width : "90%";
    height = height ? height : "90%";
    $("#divPanel").dialog("destroy");
    $("#divPanel").remove();
    $DIV = "<div id='divPanel' data-options=\"iconCls:'icon-save',resizable:true,modal:true,maximizable:true,collapsible:true\" class='easyui-dialog'></div>";
    $(document.body).append($DIV);
    $DIV = $("#divPanel");
    $DIV.html('<iframe src="' + url + '" style="width: 100%;height: 100%;border:0px;" id="iframeDIVPanel" scrolling="auto" ></iframe>');
    $DIV.dialog({
        title: title,
        autoOpen: true,
        width: width,
        height: height
    });
    $(".window-title").dblclick(function () {
        $(".panel-tool-max").click();
    });
    if (initMaximizable == true) {
        $(".panel-tool-max").click();
    }
}


//Dialog关闭js
function windowsClose() {
    $("#form1", window.parent.document).submit();
    window.parent.dialogClose("#divPanel");
}

function downloadFile(fileType) {
    alert(fileType);
    $("input[name=downloadFlag]").val("1");
    $("input[name=exportFileType]").val(fileType);
    $("#form1").submit();
}

/**
 * 单个修改方法，打开一个页面
 */
function doUpdate(title, url, width, height, key) {
    var keyValue = getIds();
    if (!validateParam(keyValue)) {
        return false;
    }
    if (url.indexOf("?") == -1) {
        url = url + "?" + key + "=" + keyValue;
    } else {
        url += "&" + key + "=" + keyValue;
    }
    //colorBoxJs(url,width,height);
    wopen(title, url, width, height);
}

/**
 * 单个修改方法，打开一个页面
 */
function doUpdate2(title, url, width, height, key) {
    var keyValue = getIds();
    if (!validateParam(keyValue)) {
        return false;
    }
    if (url.indexOf("?") == -1) {
        url = url + "?" + key + "=" + keyValue;
    } else {
        url += "&" + key + "=" + keyValue;
    }
    window.open(url);
}


/**
 * 判断是否选中了多个
 * @param keyValue
 * @returns {Boolean}
 */
function validateParam(keyValue) {
    if (!keyValue) {
        alert("请选择需要操作的记录！");
        return false;
    } else if (keyValue.indexOf(",") > -1) {
        alert("只能选择一条记录！");
        return false;
    }
    return true;
}
function loadJs() {
    $.blockUI({
        css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff'
        }
    });
}

/**
 * 删除一条数据，只能一条
 */
function toDel(url) {
    var length = 0;
    var ids = getIds();
    if (!ids) {
        alert("请选择需要删除的记录！");
        return;
    } else if (ids.indexOf(",") > -1) {
        alert("只能选择一条记录！");
        return;
    } else {
        if (confirm("确认删除？")) {
            var urls = url + ids;
            myAjaxForText(urls, null, function (data) {
                if (data.errorCode == "000000") {
                    alert("提示：操作成功");
                    $("form").submit();
                } else {
                    alert(msg);
                }
            });
        }
    }
}

//增加批量删除的方法
function delOrBatchDelForAjax(url) {
    var length = 0;
    if (!url) {
        alert("操作地址错误,请联系管理员");
        return false;
    }
    var ids = getIds();
    if (!ids) {
        alert("请选择需要删除的记录！");
        return false;
    } else {
        if (confirm("确认删除？")) {
            var urls = url;
            var data = {id: ids};
            myAjaxForText(url, data, function (data) {
                if (data.errorCode == "000000") {
                    alert("提示：操作成功");
                    $("form").submit();
                } else {
                    alert(msg);
                }
            });
        }
    }
}


//获取勾选值
function getIds() {
    var ids = '';
    $("input[name=" + $(".selectAll").attr("name") + "]").each(function () {
        if ($(this).prop("checked") && !$(this).hasClass("selectAll")) {
            var $value = $.trim($(this).val());
            if ($value) {
                ids += "," + $value;
            }
        }
    });
    if (ids) {
        ids = ids.substring(1);
    }
    return ids;
}


//增加批量更新的方法
function updateOrBatchDelForAjax(url) {
    var ids = getIds();
    if (!ids) {
        alert("请选择需要操作的记录！");
        return;
    } else {
        if (confirm("确认提交操作？")) {
            var urls = url + ids;
            myAjaxForText(urls, null, function (data) {
                if (data.errorCode == "000000") {
                    alert("提示：操作成功");
                    $("form").submit();
                } else {
                    alert(msg);
                }
            });
        }
    }
}


//封装ajax提交(返回的数据类型是字符串)
function myAjaxForText(url, data, callback) {
    if (data == null) {
        data = {'T': new Date().getTime()};
    } else {
        data['T'] = new Date().getTime();
    }
    var options = {
        url: url,
        dataType: 'JSON',
        postData: data,
        cache: false,
        onSuccessFunction: callback
    };
    myAjaxRequest(options);
}


//AJAX封装
function myAjaxRequest(par) {
    if (par.dataType == undefined) {
        par.dataType = "json";
    }
    if (par.mask == undefined) {
        par.mask = true;
    }
    if (par.blockUI == undefined) {
        par.blockUI = true;
    }

    var url = par.url;
    var postData = par.postData;
    var onSuccessFunction = par.onSuccessFunction;
    var async = par.async;
    var mask = par.mask;
    var dataType = par.dataType;
    var blockUI = par.blockUI;

    if (async != null) {
        async = true;//默认不同步
    }
    if (mask) {
        loadJs();
    }
    $.ajax({
        timeout: 300000, //5分钟
        type: "POST",
        async: async,
        url: url,
        data: postData,
        dataType: dataType,
        success: function (data, textStatus, jqXHR) {
            if (data.errorCode == '000000') {
                if (onSuccessFunction) {
                    onSuccessFunction(data);
                }
            } else if (data.errorCode == '999999') {
                alert(data.Msg);
            } else if (data.result == 'notlogin') {
                alert('请重新登录');
            } else if (data.result == "noprivilege") {
                alert("您无此权限操作该功能模块!若要开通，请联系管理员。");
            } else if (data.result == "illegalPath") {
                alert("您访问的路径为非法路径，请检查！");
            } else {
                if (onSuccessFunction) {
                    onSuccessFunction(data);
                }
            }
            setTimeout(function () {
                if (blockUI) {
                    $(".blockUI").remove();
                }
            }, 0000);//用户查看页面时间
        },
        error: function (jqXHR, textStatus, errorThrown) {
            if (textStatus == 'timeout') {
                alert("连接超时，请检查网络");
            } else if (errorThrown.indexOf('会话时间已过期') > 0) {
                //跳转到sessiontimeout.jsp
                ajaxTimeOutContinue();
            } else if (textStatus == 'error') {
                alert("请求错误");
            } else if (textStatus == 'abort') {
                alert("请求中止");
            } else if (textStatus == "parsererror") {
                alert("返回格式错误！");
            } else {
                alert(textStatus + ",HTTP error occurs" + errorThrown);
            }
            if (blockUI) {
                $(".blockUI").remove();
            }
        },
        statusCode: {
            404: function () {
                alert("404,页面不存在" + this.url);
            },
            500: function () {
                alert("500,服务器内部错误" + this.url);
            }
        }
    });
}
/**   时间相关的js**/
//得到两个日期的时间差 ，兼容IE6、7、8、9，Firefox，Chrome
function getDateRegion(beginDate, endDate) {
    var oDate1, oDate2, iDays;
    var sDate1 = beginDate.split(" ")[0];   //sDate1和sDate2是20081213格式
    var sDate2 = endDate.split(" ")[0];
    var regexp = /^(\d{1,4})(\d{1,2})(\d{1,2})$/;
    var regexp1 = /^(\d{1,4})-(\d{1,2})-(\d{1,2})$/;
    var flag = regexp.test(sDate1);
    if (!flag) {
        regexp1.test(sDate1);
    }
    var date1Year = RegExp.$1;
    var date1Month = RegExp.$2;
    var date1Day = RegExp.$3;
    var flag1 = regexp.test(sDate2);
    if (!flag1) {
        regexp1.test(sDate2);
    }
    var date2Year = RegExp.$1;
    var date2Month = RegExp.$2;
    var date2Day = RegExp.$3;
    oDate1 = new Date(date1Year + '/' + date1Month + '/' + date1Day);   //转换为12/13/2008格式
    oDate2 = new Date(date2Year + '/' + date2Month + '/' + date2Day);
    var i = (oDate2 - oDate1) / 1000 / 60 / 60 / 24;
    if (i < 0) {
        i -= 1;
    } else {
        i += 1;
    }
    iDays = i;   //把相差的毫秒数转换为天数
    return iDays;
}
//验证日期的有效性
function checkDate(str) {
    var r = str.match(/^(\d{1,4})(|\/)(\d{2})\2(\d{2})$/);
    var d = new Date(r[1], r[3] - 1, r[4]);
    return (d.getFullYear() == r[1] && (d.getMonth() + 1) == r[3] && d.getDate() == r[4]);
}
//获取当前月份
//得到今天的yyyy-MM
function getCurrentMonth() {
    var now = new Date();
    var nowYear = now.getFullYear();
    var nowMonth = now.getMonth() + 1;
    nowMonth = doHandleMonth(nowMonth);
    return nowYear + '' + nowMonth;
}
//得到今天的日期yyyy-MM-dd
function getToDay() {
    var now = new Date();
    var nowYear = now.getFullYear();
    var nowMonth = now.getMonth();
    var nowDate = now.getDate();
    newdate = new Date(nowYear, nowMonth, nowDate);
    nowMonth = doHandleMonth(nowMonth + 1);
    nowDate = doHandleMonth(nowDate);
    return nowYear + '' + nowMonth + '' + nowDate;
}
function doHandleMonth(month) {
    if (month.toString().length == 1) {
        month = "0" + month;
    }
    return month;
}
//得到昨天的日期yyyy-MM-dd
function getYesterDay() {
    var now = new Date();
    var nowYear = now.getFullYear();
    var nowMonth = now.getMonth();
    var nowDate = now.getDate();
    var newdate = new Date(nowYear, nowMonth, nowDate);
    var newtimems = newdate.getTime() - (24 * 60 * 60 * 1000);
    var yesd = new Date(newtimems);
    var yesYear = yesd.getFullYear();
    var yesMonth = yesd.getMonth();
    var yesDate = yesd.getDate();
    yesMonth = doHandleMonth(yesMonth + 1);
    yesDate = doHandleMonth(yesDate);
    return yesYear + '' + yesMonth + '' + yesDate;
}
//相隔今天多少年的日期，还没有验证过 
function getBetweenYearDate(betweenYear) {
    var date = new Date();
    var strYear = date.getFullYear() + parseInt(betweenYear);
    var strDay = date.getDate();
    var strMonth = date.getMonth() + 1;
    if (strMonth < 10) {
        strMonth = "0" + strMonth;
    }
    if (strDay < 10) {
        strDay = "0" + strDay;
    }
    datastr = strYear + '' + strMonth + '' + strDay;
    return datastr;
}
//距离今天多少月的日期(正负整数) 
function getBetweenMonth(betweenMonth) {
    var date = new Date();
    var daysInMonth = new Array([0], [31], [28], [31], [30],
        [31], [30], [31], [31], [30], [31], [30], [31]);
    var strYear = date.getFullYear();
    var strDay = date.getDate();
    var strMonth = date.getMonth() + 1 + parseInt(betweenMonth);
    if (strYear % 4 == 0 && strYear % 100 != 0) {
        daysInMonth[2] = 29;
    }
    if (strMonth - 12 > 0 && betweenMonth > 0) {
        strYear += parseInt(strMonth / 12);
        strMonth = (strMonth % 12);
    } else if (strMonth < 0 && betweenMonth < 0) {
        strYear -= parseInt((strMonth * -1 + 12) / 12);
        strMonth = 12 - parseInt(strMonth % 12) * -1;
    } else if (strMonth > 0 && betweenMonth < 0) {
//		strYear = strYear;
//		strMonth = strMonth;
    } else if (strMonth == 0 && betweenMonth < 0) {
        strYear -= 1;
        strMonth = 12;
    }
    strDay = daysInMonth[strMonth] >= strDay ? strDay
        : daysInMonth[strMonth];
    if (strMonth < 10) {
        strMonth = "0" + strMonth;
    }
    if (strDay < 10) {
        strDay = "0" + strDay;
    }
    datastr = strYear + '' + strMonth + '' + strDay;
    return datastr;
}

//n个月后
function getDateByNumMonth(numMonth) {
    var date = new Date();
    var valueInt = parseInt(numMonth);
    date.setMonth(date.getMonth() + valueInt);
    var strMonth = date.getMonth() + 1;
    var strDay = date.getDate();
    if (strMonth < 10) {
        strMonth = "0" + strMonth;
    }
    if (strDay < 10) {
        strDay = "0" + strDay;
    }
    return date.getFullYear() + '' + strMonth + '' + strDay;
}

//取得当前日期和时间的函数
function getCurrentDateAndTime() {
    var myDate = new Date();
    return myDate.toLocaleString(); //获取日期与时间
}

/** 页面效果相关的js**/
//增加jquery_validate验证class
function addCss(obj, value) {
    if ($(obj) != null) {
        $(obj).each(function () {
            var classValue = $(this).attr("class");
            if (classValue != undefined) {
                var indexValue = classValue.indexOf("}");
                if (indexValue != undefined) {
                    var containtsIndex = classValue.indexOf(value);
                    if (indexValue != -1) {
                        if (containtsIndex == -1) {
                            $(this).removeClass(classValue);
                            classValue = classValue.substring(0, indexValue) + "," + value + classValue.substring(indexValue, classValue.length);
                            $(this).addClass(classValue);
                        }
                    } else {
                        $(this).addClass("{" + value + "}");
                    }
                }
            }
        });
    }
}
function removeClass(obj, value) {
    if ($(obj) != null) {
        $(obj).each(function () {
            var classValue = $(this).attr("class");
            if (classValue != undefined) {
                var indexValue = classValue.indexOf("}");
                if (indexValue != undefined) {
                    var containtsIndex = classValue.indexOf(value);
                    if (indexValue != -1 && containtsIndex != -1) {
                        $(this).removeClass(classValue);
                        if (classValue.indexOf("{" + value + "}") == -1) {
                            classValue = classValue.replace(value, "");
                        } else {
                            classValue = classValue.replace("{" + value + "}", "");
                        }
                        $(this).addClass(classValue);
                    }
                }
            }
        });
    }
}
//classId:class值,value:显示的说明 
function divUtils(classId, info, flag) {
//		if(!$("."+classId).parents("form").hasClass("readonlyStyle")){
    var classStyle;
    if (flag == "1") {
        $("." + classId).hide();
        classStyle = "toggler-closed";
    } else {
        $("." + classId).show();
        classStyle = "toggler-opened";
    }
    var length = findMaxLength(classId);
    if ($("." + classId).last().next() != null && !$("." + classId).last().next().hasClass("toggleClass") && !$("." + classId).last().next().hasClass(classId + flag)) {
        $("." + classId).last().after("<tr class='toggleClass'><td colspan='" + length + "'><a style=\"vertical-align:middle;\" class='toggler " + classStyle + " " + classId + flag + "'></a></td></tr>");
        if (flag == "1") {
            $("." + classId + flag).attr("title", "显示" + info);
        } else {
            $("." + classId + flag).attr("title", "隐藏" + info);
        }
    }
    $("." + classId + flag).click(function () {
        if ($(this).hasClass("toggler-closed")) {
            $(this).removeClass("toggler-closed");
            $(this).addClass("toggler-opened");
            $("." + classId + flag).attr("title", "隐藏" + info);
            //把提示都去掉
            $(".tipsy").remove();
            $(".formError").remove();
            $("." + classId).show();
        } else {
            $(this).removeClass("toggler-opened");
            $(this).addClass("toggler-closed");
            $("." + classId + flag).attr("title", "显示" + info);
            //把提示都去掉
            $(".tipsy").remove();
            $(".formError").remove();
            $("." + classId).hide();
        }
    });
//		}
}
function findMaxLength(classId) {
    var length = $("." + classId).children().length;
    $("." + classId).siblings().each(function () {
        if (parseInt(length) < parseInt($(this).children().length)) {
            length = $(this).children().length;
        }
    });
    return length;
}

//返回
function doHistory() {
    window.history.go(-1);
}


/**colorBoxUtils.jsp***/
function subSomething() {
    //当页面加载状态
    if (document.readyState == "complete") {
        $(".blockUI").remove();
    }
}

/***easydialog.jsp***/
//弹窗
function showMsg(titleName, msg) {
    easyDialog.open({
        container: {
            header: titleName,
            content: msg
        },
        drag: true
    });
}

function initDate() {
    //添加date的样式
    $(".dateClass").addClass("Wdate");

    //循环添加时间控件
    $(".dateClass").each(function (index, item) {
        var $_dateThis = $(this);
        var $dataFormat = $_dateThis.attr("dataFormat");
        if (!$dataFormat) {
            $dataFormat = "yyyy-MM-dd";
        }

        $_dateThis.unbind("click");
        $_dateThis.unbind("focus");

        $_dateThis.click(function () {
            WdatePicker({dateFmt: $dataFormat});
        });

        $_dateThis.focus(function () {
            var dateOption = {"dateFmt": $dataFormat};
            var $MinID = $_dateThis.attr("minDate");
            if ($MinID) {
                var $minDate = $("#" + $MinID);
                if ($minDate.length > 0 && $minDate.hasClass("dateClass")) {
                    dateOption["minDate"] = "#F{$dp.$D('" + $MinID + "')}";
                }
                $_dateThis.removeAttr("maxDate");
            }

            var $MaxID = $_dateThis.attr("maxDate");
            if ($MaxID) {
                var $maxDate = $("#" + $MaxID);
                if ($maxDate.length > 0 && $maxDate.hasClass("dateClass")) {
                    dateOption["maxDate"] = "#F{$dp.$D('" + $MaxID + "')}";
                    dateOption["onpicked"] = function () {
                        $maxDate.focus();
                    }
                }
                $_dateThis.removeAttr("minDate");
            }

            if ($_dateThis.hasClass("required")) {
                dateOption["isShowClear"] = false;
            } else {
                dateOption["dateFmt"] = $dataFormat;
            }
            WdatePicker(dateOption)
        })
    });
}

function showAlert(option) {
    easyDialog.open({
        container: {
            header: titleName,
            content: msg
        },
        drag: true
    });
}

function showConfirm(option) {
    easyDialog.open({
        container: {
            header: "确认",
            content: option.Msg,
            yesFn: option.yesFunction,
            noFn: true
        },
        drag: true
    });
}

/**
 * 短信模版配置
 */
function dialogsmsSetting(confirmUrl, cancelUrl, id) {
    $("#ConfirmationWindow").dialog("destroy");
    $("#ConfirmationWindow").remove();
    $(document.body).append("<div id='ConfirmationWindow'>确认是否需要配置短信模版?</div>");
    $("#ConfirmationWindow").dialog({
        title: "确认是否发送短信",
        width: "400px",
        height: "200px",
        buttons: [
            {
                text: "确认发送",
                handler: function () {
                    if (confirmUrl.indexOf("?") == -1) {
                        confirmUrl = confirmUrl + "?t=" + new Date().getTime();
                    } else {
                        confirmUrl = confirmUrl + "&t=" + new Date().getTime();
                    }
                    confirmUrl = confirmUrl + "&id=" + id;
                    wopen("配置短信模版", confirmUrl, 600, 350);
                    $("#ConfirmationWindow").dialog("destroy");
                }
            },
            {
                text: "不需要发送",
                handler: function () {
                    alert("985");
                    myAjaxForText(cancelUrl, {
                        noteFlag: "1",
                        approveType: "ADD_NOTE",
                        status: "APPROVE_3",
                        fileApproveId: id
                    }, function (data) {
                        if (data.errorCode == "000000") {
                            alert(data.Msg);
                            $("#ConfirmationWindow").dialog("destroy");
                            $("#form1").submit();
                        } else {
                            alert(data.Msg);
                        }
                        $(".blockUI").remove();
                    });
                }
            }
        ]
    });
}

/**
 * 批量文件是否确认审核
 * @param url
 * @param fileApproveId
 */
function dialogAuthWindow(url, fileApproveId) {
    $("#ConfirmationWindow").dialog("destroy");
    $("#ConfirmationWindow").remove();
    $(document.body).append("<div id='ConfirmationWindow'>文件已确认审核?</div>");
    $("#ConfirmationWindow").dialog({
        title: "审核确认",
        width: "400px",
        height: "200px;",
        buttons: [
            {
                text: "审核通过",
                handler: function () {
                    myAjaxForText(url, {
                        approveType: "REVIEW",
                        fileApproveId: fileApproveId,
                        status: "APPROVE_2"
                    }, function (data) {
                        if (data.errorCode == "000000") {
                            alert("操作成功");
                            $("#ConfirmationWindow").dialog("destroy");
                            $("#form1").submit();
                        } else {
                            alert(data.Msg);
                        }
                        $(".blockUI").remove();
                    });
                }

            },
            {
                text: "审核不通过",
                handler: function () {
                    myAjaxForText(url, {
                        approveType: "REVIEW",
                        fileApproveId: fileApproveId,
                        status: "CANCEL_1"
                    }, function (data) {
                        alert("1036");
                        if (data.errorCode == "000000") {
                            alert("操作成功");
                            $("#ConfirmationWindow").dialog("destroy");
                            $("#form1").submit();
                        } else {
                            alert(data.Msg);
                        }
                        $(".blockUI").remove();

                    });
                }
            }
        ]
    });
}

/**
 * 批量文件确认是否执行
 * @param url
 * @param revocationUrl
 * @param fileApproveId
 */
function dialogProWindow(url, revocationUrl, fileApproveId) {
    $("#ConfirmationWindow").dialog("destroy");
    $("#ConfirmationWindow").remove();
    $(document.body).append("<div id='ConfirmationWindow'>数据验证完毕，确认执行？</div>");
    $("#ConfirmationWindow").dialog({
        title: "执行",
        width: "400px",
        height: "200px;",
        buttons: [
            {
                text: "确认执行",
                handler: function () {
                    myAjaxForText(url, {id: fileApproveId}, function (data) {
                        alert("1075");
                        if (data.errorCode == "000000") {
                            alert("执行成功，程序正在处理中");
                            $("#ConfirmationWindow").dialog("destroy");
                            $("#form1").submit();
                        } else {
                            alert(data.Msg);
                        }
                        $(".blockUI").remove();
                    });
                }
            },
            {
                text: "确认不执行",
                handler: function () {
                    myAjaxForText(revocationUrl, {id: fileApproveId}, function (data) {
                        if (data.errorCode == "000000") {
                            alert("操作成功");
                            $("#ConfirmationWindow").dialog("destroy");
                            $("#form1").submit();
                        } else {
                            alert(data.Msg);
                        }
                        $(".blockUI").remove();
                    });
                }
            }
        ]
    });
}


/**
 * 关闭弹出框
 * @param documentID
 */
function dialogClose(documentID) {
    $(documentID).dialog("destroy");
}

/**
 * 请求后台操作
 * @param option
 * option.url 请求的路径
 * option.data 请求的参数，JSON格式
 */
function ajaxRequest(option) {
    myAjaxForText(option.url, option.data, function (data) {
        alert("1116");
        if (data.errorCode == "000000") {
            alert(data.Msg);
            $("#form1").submit();
        } else {
            alert(data.Msg);
        }
        $(".blockUI").remove();
    })
}
//资源操作说明
function showMsgForResourceInfo() {
    var titleName = "资源操作说明：";
    var msg = "第一：如果只是一个菜单，不是界面，资源URL配置成'1'或'common.jsp'<br>" +
        "第二：如果配置菜单界面，资源URL为访问路径URL<br>第三：如果是父链接，就定义为0<br>" +
        "第四：如果配置按钮权限，资源URL为访问按钮URL路径<br>" +
        "第五：如果配置是no，则右导航栏不显示<br>";
    showMsg(titleName, msg);
}

/**
 * 缓存页面信息
 */
function cachePageInfo() {
    //文本框
    $("input[type='text'],input[type='hidden'],select,textarea").each(function () {
        $(this).attr("cache-data", $(this).val());
    });
}

function resetPageInfo() {
    $("input[type='text'],input[type='hidden'],select,textarea").each(function () {
        $(this).val($(this).attr("cache-data"));
    });
}


