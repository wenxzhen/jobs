package com.taobao.zeus.web.platform.client.app.document;

import com.google.gwt.user.client.ui.IsWidget;

public interface DocumentView extends IsWidget{

}
