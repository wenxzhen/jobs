package com.taobao.zeus.web.platform.client.app.schedule;

import com.google.gwt.user.client.ui.IsWidget;

public interface ScheduleView extends IsWidget{

}
