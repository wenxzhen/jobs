package com.taobao.zeus.web.platform.client.module.filemanager;

import com.google.web.bindery.autobean.shared.AutoBean;
import com.google.web.bindery.autobean.shared.AutoBeanFactory;

public interface FileModelFactory extends AutoBeanFactory {

//	  AutoBean<FileModel> fileModel();
}
