package com.taobao.zeus.web.platform.client.module.jobdisplay;

import com.taobao.zeus.web.platform.client.util.Presenter;
import com.taobao.zeus.web.platform.client.util.place.PlaceHandler;

public interface JobDisplayPresenter extends Presenter, PlaceHandler{

    public static final String TAG = "jobdisplay";

}
