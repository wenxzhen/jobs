package com.taobao.zeus.web.platform.client.app.report;

import com.taobao.zeus.web.platform.client.util.Presenter;

public interface ReportPresenter extends Presenter{

}
