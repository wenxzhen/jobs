package com.taobao.zeus.web.platform.client.app.report;

import com.google.gwt.user.client.ui.IsWidget;

public interface ReportView extends IsWidget{

}
