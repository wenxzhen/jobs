package com.taobao.zeus.util;

public class ExitCodes {
	//zk通知失败的exit code
	public static final int NOTIFY_ZK_FAIL=10001;
}
